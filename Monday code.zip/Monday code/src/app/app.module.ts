import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BindingComponent } from 'src/learning/binding/binding.component';

import { DIModule } from 'src/learning/di/di.module';
import { MobileProductComponent } from 'src/learning/binding/mobileproduct.component';

@NgModule({
  declarations: [
    AppComponent, BindingComponent, MobileProductComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    DIModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
