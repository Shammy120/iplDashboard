import { Component, OnInit } from '@angular/core';
import { ProductService } from './product.service';

@Component({
    selector: 'app-di',
    templateUrl: './product.component.html',
    providers:[ProductService]
})

export class ProductComponent implements OnInit {
    constructor(private ps: ProductService) { }
    product:any
    ngOnInit() { 
      this.product =  this.ps.getProductInfo()
    }
}