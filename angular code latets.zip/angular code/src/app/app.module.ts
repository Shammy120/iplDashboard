import { ApplicationRef, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BindingComponent } from 'src/learning/binding/binding.component';

import { DIModule } from 'src/learning/di/di.module';
import { MobileProductComponent } from 'src/learning/binding/mobileproduct.component';
import { BindingModule } from 'src/learning/binding/binding.module';
import { SignalComponent } from './signal.component';
import { FormsModule } from '@angular/forms';
import { ChildComponent, LifecycleComponent } from 'src/learning/lifecycle/lifecycle.component';
import { DynamicComponent } from 'src/learning/dynamic/dynamic.component';

@NgModule({
  declarations: [
    AppComponent, BindingComponent, MobileProductComponent,
    SignalComponent, LifecycleComponent, ChildComponent,
    DynamicComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    DIModule,
    BindingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { 
  // constructor(appRef:ApplicationRef){
  //   const originalTick=appRef.tick //cds
  //   appRef.tick=function(){
  //     const winPerf=window.performance
  //     const start=winPerf.now()
  //     const retValue=originalTick.apply(this)
  //     const end= winPerf.now()
  //     const runtime = end - start;
  //     window.console.log(`change detectio time: ${runtime}ms`)
  //     return retValue;
  //   }
  // }
}
