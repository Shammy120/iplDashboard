import { Injectable } from '@angular/core';
import { Product } from './product';

interface Ilogger{
    logMessage(msg:string) : void
}
@Injectable()
export class ProductService implements Ilogger {
    constructor() { }
    logMessage(msg: string): void {
        console.log("someone called service:" + msg)
    }
    getProductInfo() : Product{
        this.logMessage('about product')
        return new Product(101, 'mouse', 600)
    }
}