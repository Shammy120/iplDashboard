//Entity module, object module, DTo
export class Product{
    constructor(
        public pid:number,
        public pname:string,
        public price:number
    ){

    }
}