import { Injectable } from '@angular/core';

@Injectable({providedIn: 'root'})
export class StockService {
    constructor() { }
    public message:string="Stock value of boa is $500"

    getStockInfo():string{
        return this.message;
    }
}