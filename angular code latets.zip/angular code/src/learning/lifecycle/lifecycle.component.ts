import { Component, OnInit ,Input ,
    ChangeDetectorRef,
    OnChanges,
    SimpleChanges} from '@angular/core';
    
    @Component({
      selector: 'app-lifecycle',
      template: `
      <div class="bg-warning">
         <h2>Parent component</h2>
         <h3 class="container">
          <input type="text" [(ngModel)]="search">
        </h3>
        <child [search]="search"></child>
    </div>
      `
    })
    //{'search':'printer'}
    export class LifecycleComponent {
      search:string="printer"
      constructor() { }
    }
    //child component
    @Component({
      selector: 'child',
      template: `
      <h2 class="container bg-info text-light">Search  Text: {{search}}</h2>
      `
    })
    
    export class ChildComponent implements OnInit,OnChanges {
      @Input()
      search:string=' '
      count:number=0
    
      constructor(private cd:ChangeDetectorRef) {
        console.log(` in constructor of child : ${this.search}`)//null
        this.cd.detach()
      }
    
      ngOnChanges(changes:SimpleChanges):void{ //immutability
        //fires every time when state changes in this component, from parent
        //validations for state.
        console.log(` in onChanges of child : ${this.search}`)
        for (let key in changes){
          console.log(` ${key} changed :
                  - Current : ${changes[key].currentValue}
                  - Previous : ${changes[key].previousValue}`)
        }
      }
      ngOnInit() {
        //fired only once, make REST api calls , subcribe to web socket, observable
        console.log(` in ngInit of child : ${this.search}`)//printer
      }
    
      ngDoCheck():void{
        //fired everytime when state changes
        //CDS  logic
        console.log(` in ngDC of child : ${this.search}`)
        if(this.search.length===10){
          this.cd.detectChanges()
        }
    
      }

      ngAfterViewChecked(){
        //ired everytime , DOM implementation
        console.log("I am in AVC")
      }

      ngOnDestroy(){
        //fired only once
        //clean the cache to avoid memory leak, unsubscribe to websocket/observable
        console.log("component removed from shadow dom");
        // this.subscriber?.unsubscribe()
      }
    
    }
    