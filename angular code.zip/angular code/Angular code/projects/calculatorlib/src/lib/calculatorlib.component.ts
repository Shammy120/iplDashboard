import { Component } from '@angular/core';
import { CalculatorlibService } from './calculatorlib.service';

@Component({
  selector: 'lib-calculatorlib',
  template: `
    <p>
      calculatorlib works!
    </p>
    <button (click) = "calculate()">calculate PNR Interest</button>
    Int Amount is {{amount}}
  `
})
export class CalculatorlibComponent {
  constructor(private service:CalculatorlibService){

  }
  amount:number=0;
  calculate(){
    this.amount= this.service.calc_pnr(500,10,12);
  }
}
