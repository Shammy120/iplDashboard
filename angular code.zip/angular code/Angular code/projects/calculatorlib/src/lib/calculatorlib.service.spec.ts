import { TestBed } from '@angular/core/testing';

import { CalculatorlibService } from './calculatorlib.service';

describe('CalculatorlibService', () => {
  let service: CalculatorlibService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CalculatorlibService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
