import { ApplicationRef, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BindingComponent } from 'src/learning/binding/binding.component';

import { DIModule } from 'src/learning/di/di.module';
import { MobileProductComponent } from 'src/learning/binding/mobileproduct.component';
import { BindingModule } from 'src/learning/binding/binding.module';
import { SignalComponent } from './signal.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ChildComponent, LifecycleComponent } from 'src/learning/lifecycle/lifecycle.component';
import { DynamicComponent } from 'src/learning/dynamic/dynamic.component';
import { HttpComponent } from 'src/learning/http/http.component';
import { HttpService } from 'src/learning/http/http.service';
import { HttpClientModule } from '@angular/common/http';
import { WeatherComponent } from 'src/learning/http/weather.component';
import { CalculatorlibModule } from 'projects/calculatorlib/src/public-api';

@NgModule({
  declarations: [
    AppComponent, BindingComponent, MobileProductComponent,
    SignalComponent, LifecycleComponent, ChildComponent,
    DynamicComponent, HttpComponent,
    WeatherComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    DIModule,
    BindingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    CalculatorlibModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { 
  // constructor(appRef:ApplicationRef){
  //   const originalTick=appRef.tick //cds
  //   appRef.tick=function(){
  //     const winPerf=window.performance
  //     const start=winPerf.now()
  //     const retValue=originalTick.apply(this)
  //     const end= winPerf.now()
  //     const runtime = end - start;
  //     window.console.log(`change detectio time: ${runtime}ms`)
  //     return retValue;
  //   }
  // }
}
