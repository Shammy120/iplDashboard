import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { StockComponent } from './stock.component';

@Component({
    selector: 'app-dynamic',
    template: `
    <h2 class="text-primary">Dynamic Component</h2>
    <button (click)="load()"> Shoq stock info</button>
    `
})

export class DynamicComponent implements OnInit {
    constructor(private vcr:ViewContainerRef) { }

    ngOnInit() { }

    load(){
        const ref =this.vcr.createComponent(StockComponent) //dynamic injection
        ref.changeDetectorRef.detectChanges()
        //const ref = this.vcr.createComponent(
        // import(stockModule => stockModule.default)    
        // )
    }
}