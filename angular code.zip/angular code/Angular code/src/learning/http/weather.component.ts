import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { response } from 'express';
import { map, debounceTime, switchMap, catchError, Observable, of } from 'rxjs';



@Component({
    selector: 'app-weather',
    templateUrl: './weather.component.html'
})

export class WeatherComponent implements OnInit {
    private baseUrl:String='https://api.openweathermap.org/data/2.5/weather?q='
    private urlSuffix='&units=imperial&appid=ca3f6d6ca3973a518834983d0b318f73'

    searchInput:FormControl=new FormControl()
    city:string | undefined
    temperature:string | undefined
    description:string|undefined
    humidity:String|undefined

    loading:boolean|undefined

    errorMsg:string=''

    constructor(private http:HttpClient) { }

    ngOnInit() { 
        this.searchInput.valueChanges.pipe(map((data) =>{
            this.loading=true
            this.errorMsg=''
            return data
        }))
        .pipe(debounceTime(3000))
        .pipe(switchMap((city:string) => {
            return this.getWeather(city)
            .pipe(catchError(err => {
                this.errorMsg='Error....Please try again'
                this.loading = false
                return of([])
            }))
        }))
        .subscribe({
            next:(response : any) => {
                if(this.errorMsg == ''){
                    this.city = response.name + '' + response.sys.country;
                    this.description = response.weather[0].description;
                    this.temperature = response.main.temp;
                    this.humidity = response.main.humidity;
                }
                this.loading=false;
            },
            error: (err => {
                this.loading =false;
                this.errorMsg = 'Errorrrrrr';
                return of(err)
            }),
            complete:() =>{
                console.log('all work done')
                return of([])
            }
        })
        this.searchInput.setValue('hyderabad')
    }

    getWeather(city:string):Observable<Array<String>>{
        return this.http.get(this.baseUrl+city+this.urlSuffix)
        .pipe(map((response:any) =>{
            console.log(response);
            return response
        } ))
    }
}