//live stock details for BofA and send notification to customer every 1 sec
//event handling with @output, data flow from top to bottom with @input, strongly typed event
//with interface and create a module for live stock details

import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

export interface IPriceQuote{
    stockSymbol:string,
    lastPrice:number
}

export interface ILogger{
    log(msg:string):void
}

@Component({
    selector: 'app-dataflow',
    template: `
    <div class="bg-warning">
    <h2> Parent Component </h2>
    <h3>Stock details: {{stockSymbol}} - {{price | currency:'USD'}}</h3>
        <price-quoter (lastPriceEvent)="priceQuoteHandler($event)"></price-quoter>
        <notifier [info]="stockInfo"></notifier>
    </div>
    `
})

//parent component
export class DataFlowComponent implements OnInit {
    constructor() { }
    stockSymbol:String='';
    price:number=0;
    stockInfo:IPriceQuote={'stockSymbol':'','lastPrice':0};

    priceQuoteHandler(event:IPriceQuote){
        this.stockSymbol = event.stockSymbol;
        this.price=event.lastPrice;
        this.stockInfo= event;
    }
    ngOnInit() { }
}

//----------------
//child Component
@Component({
    selector: 'price-quoter',
    template: `
    <div class="bg-secondary">
        <h2 class="text-dark"> Child PriceQuoter Comp</h2>
        <h3> In Child: {{company}} - {{price | currency:'USD'}}</h3>
    </div>
    `
})

export class PriceQuoterComponent implements OnInit, ILogger {

    @Output()
    lastPriceEvent:EventEmitter<IPriceQuote> = new EventEmitter();
    company:string="Bank of America";
    price:number=0
    constructor() {
        window.setInterval(() => {
            //http.get(url,options, body)
            let priceQuote:IPriceQuote={
                stockSymbol:this.company,
                lastPrice: 100 * Math.random()
            }
            this.price = priceQuote.lastPrice;
            this.lastPriceEvent.emit(priceQuote);
        }, 1000)
    }
    log(msg: string): void {
        console.log("Price quoter running..."+msg)
        //http.post(url,msg)
    }

    ngOnInit() { }
}

//--------------
//notifier component

@Component({
    selector: 'notifier',
    template: `
    <div class="bg-success">
        <h2> Notifier Component </h2>
        <h3>Stock details: {{info.stockSymbol}} - {{info.lastPrice | currency:'USD'}}</h3>
    </div>
    `
})

export class NotifierComponent implements OnInit {
    constructor() { }

    @Input({required:true})
    info:IPriceQuote={'stockSymbol':'', 'lastPrice':0};
    ngOnInit() { }
}