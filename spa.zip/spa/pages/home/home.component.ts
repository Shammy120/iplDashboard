import { Component, OnInit } from '@angular/core';

@Component({
    template: `
    <h1 class="bg-danger text-warning text-center">SPA Project in Angular<h1>
    `
})

export class HomeComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}