import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SPARouterModule } from './spa.routes';
import { SpaComponent } from './spa.component';
import { HomeComponent } from './pages/home/home.component';
import { LoginComponent } from './pages/login/login.component';
import { ContactListComponent } from './pages/contacts/contactlist.component';
import { ShowComponent } from './pages/contacts/show.component';


@NgModule({
    imports: [CommonModule, SPARouterModule, FormsModule],
    exports: [SpaComponent],
    declarations: [SpaComponent, HomeComponent, LoginComponent, ContactListComponent,
    ShowComponent],
    providers: [],
})
export class SPAModule { }
