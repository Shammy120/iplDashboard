import { Routes, RouterModule } from "@angular/router";
import { HomeComponent } from "./pages/home/home.component";
import { PageNotFoundComponent } from "./pages/notfound/pagenotfound.component";
import { LoginComponent } from "./pages/login/login.component";
import { ContactListComponent } from "./pages/contacts/contactlist.component";
import { ShowComponent } from "./pages/contacts/show.component";

const customRoutes:Routes=[
    {path:'', component:HomeComponent},
    {path:'login',component:LoginComponent},
    {path:'contacts',component:ContactListComponent},
    {path:'show/:selected',component:ShowComponent},
    {path:'**',component:PageNotFoundComponent}
]

export const SPARouterModule= RouterModule.forRoot(customRoutes)