import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CalculatorlibComponent } from './calculatorlib.component';

describe('CalculatorlibComponent', () => {
  let component: CalculatorlibComponent;
  let fixture: ComponentFixture<CalculatorlibComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CalculatorlibComponent]
    });
    fixture = TestBed.createComponent(CalculatorlibComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
