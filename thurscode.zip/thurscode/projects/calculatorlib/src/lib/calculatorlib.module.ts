import { NgModule } from '@angular/core';
import { CalculatorlibComponent } from './calculatorlib.component';



@NgModule({
  declarations: [
    CalculatorlibComponent
  ],
  imports: [
  ],
  exports: [
    CalculatorlibComponent
  ]
})
export class CalculatorlibModule { }
