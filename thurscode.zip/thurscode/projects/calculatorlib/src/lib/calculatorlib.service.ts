import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CalculatorlibService {

  constructor() { }
    calc_pnr(p:number, n:number, r:number){
      return (p*n*r)/100;
    }
  }



