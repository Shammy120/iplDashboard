// import { Component, OnInit, signal, effect, computed } from '@angular/core';

// @Component({
//     selector: 'app-signal',
//     // standalone:true,
//     template: `
//     <h2>Signal in Angular 16</h2>
//     <h3>Enter EMail: <input type="text" [(ngModel)] = "mail"></h3>{{mail}}
//     fullName :{{fullName()}}
//     <button (click)="setName('kumar')">Click me</button>
//     `
// })

// export class SignalComponent implements OnInit {
//     firstName=signal('Shammy')
//     lastName=signal('kumar')
//     fullName=computed(() => `${this.firstName} ${this.lastName}`)
//     mail:string=''
//     constructor() { 
//         effect(() => console.log('Name changed', this.fullName())) 
//     }

//     setName(newName: string){
//         this.firstName.set(newName);
//     }

//     ngOnInit() { }
// }
import { Component, OnInit,signal ,effect,computed} from '@angular/core';

@Component({
  selector: 'app-signal',
  template: `
  <h2>Signal in Angular 16</h2>
  <h4>Enter Email: <input type="text" [(ngModel)]="mail"></h4> {{mail}}

  Fullname:{{fullName()}}
  <button (click)="setName('dhulipala')">Click me</button>
  `
})

export class SignalComponent implements OnInit {
  firstName=signal('Murthy')
  lastName=signal('Srirama')
  fullName=computed( ()=>` ${this.firstName()} ${this.lastName()}`)

  mail:string=' '
  constructor() {
    effect( ()=>console.log('Name details',this.fullName()))//
   }

   setName(newName:string){
    this.firstName.set(newName)
   }
  ngOnInit() { }
}
