import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpRequest } from '@angular/common/http'
import { filter, map } from 'rxjs';
 
const sso_token='kjsd83lkfsd439344lkslkjasklf32f'
const httpOptions:any={
    headers:new Headers({
        'token':sso_token,
        'content-type':'application/json'
    })
}
@Injectable({providedIn: 'root'})
export class HttpService {
    constructor(private http: HttpClient) { }
    baseUrl='http://localhost:3000'

    getFoods():any{
        return this.http.get(this.baseUrl+'/api/food')
        .pipe(filter((response : any) => response != undefined))
        .pipe(map((resp:any) => {
            console.log(resp); 
            return resp
        }))
    }
    addFood(food:any){
        let body = JSON.stringify(food);
        return this.http.post(this.baseUrl+'/api/food/', body, httpOptions);
    }
    updateFood(food:any){
        let body = JSON.stringify(food);
        return this.http.put(this.baseUrl+'/api/food/', body, httpOptions);
    }
    deleteFood(food:any){
        return this.http.delete(this.baseUrl+'/api/food/'+food.id)
    }
}