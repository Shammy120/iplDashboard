import { Component, OnInit } from '@angular/core';

@Component({
    template: `
    <h3 class="bg-dark text-light">About bank of america</h3>
    <h5>La la la la la</h5>
    `
})

export class AboutComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}