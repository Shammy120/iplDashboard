import { NgModule } from '@angular/core';
import { AboutComponent } from './about.component';
import { CommonModule } from '@angular/common';
import aboutRoutes from './about.routes';


@NgModule({
    imports: [CommonModule,aboutRoutes],
    exports: [],
    declarations: [AboutComponent],
    providers: [],
})
export class AboutModule { }
