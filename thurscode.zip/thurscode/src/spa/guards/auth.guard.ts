import { inject } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivateFn, RouterStateSnapshot } from '@angular/router';
import { Session } from '../services/globals';

export const AuthGuard: CanActivateFn = (
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
    ) => {
        // alert("I am auth guard, stop")
        if(Session.authenticated == true){
            alert("welcome");
            return true;
        }else{
            alert("Sorry")
            return false
        }

        // return true;
}