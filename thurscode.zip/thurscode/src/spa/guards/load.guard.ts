

import { Injectable } from '@angular/core';
import { CanLoad, Route } from '@angular/router';

import { Session } from '../services/globals';

@Injectable({providedIn: 'root'})
export class LoadGuard implements CanLoad {
  constructor() { }
  canLoad(route: Route): boolean {
    if (Session.authenticated){
      alert("Lazy loading the About module from server")
      return true
    }
    else{
     alert('Sorry... login to download about module')
     return false
    }
  }

}
