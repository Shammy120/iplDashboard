import { Component, OnInit } from '@angular/core';

@Component({
    template: `
    <div class="bg-danger text-light">
        <h2>Page Not found - 404 error</h2>
        <h5>Sorry</h5>
    </div>
    `
})

export class PageNotFoundComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}