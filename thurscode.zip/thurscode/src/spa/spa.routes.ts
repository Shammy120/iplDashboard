import { Routes, RouterModule } from "@angular/router";
import { HomeComponent } from "./pages/home/home.component";
import { PageNotFoundComponent } from "./pages/notfound/pagenotfound.component";
import { LoginComponent } from "./pages/login/login.component";
import { ContactListComponent } from "./pages/contacts/contactlist.component";
import { ShowComponent } from "./pages/contacts/show.component";
import { AuthGuard } from "./guards/auth.guard";
import { LoadGuard } from "./guards/load.guard";

const customRoutes:Routes=[
    {path:'', component:HomeComponent},
    {path:'login',component:LoginComponent},
    {path:'contacts',canActivate:[AuthGuard], component:ContactListComponent},
    {path:'show/:selected',component:ShowComponent},
    {path:'about',canLoad:[LoadGuard],loadChildren:() => 
        import('./about/about.module').then( m => m.AboutModule)},
    {path:'**',component:PageNotFoundComponent}
]

export const SPARouterModule= RouterModule.forRoot(customRoutes)