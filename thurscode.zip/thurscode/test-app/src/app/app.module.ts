import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { CalculatorlibModule } from 'calculatorlib';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    CalculatorlibModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
