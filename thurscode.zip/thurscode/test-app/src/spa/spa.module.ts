import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';


@NgModule({
    imports: [CommonModule, ],
    exports: [],
    declarations: [],
    providers: [],
})
export class SPAModule { }
