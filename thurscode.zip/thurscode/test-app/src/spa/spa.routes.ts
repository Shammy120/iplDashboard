import { Routes, RouterModule } from "@angular/router";
import { HomeComponent } from "./pages/home/home.component";
import { PageNotFoundComponent } from "./pages/notfound/pagenotfound.component";

const customRoutes:Routes=[
    {path:'', component:HomeComponent},
    {path:'**',component:PageNotFoundComponent}
]

export const SPARouterModule= RouterModule.forRoot(customRoutes)